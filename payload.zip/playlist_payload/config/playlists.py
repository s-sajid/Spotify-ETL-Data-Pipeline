def spotify_playlist_1():
    playlists = {"Rap_Caviar": "spotify:playlist:37i9dQZF1DX0XUsuxWHRQd"}
    return playlists

def spotify_playlist_2():
    playlists = {"Operator": "spotify:playlist:37i9dQZF1DWVY4eLfA3XFQ"}
    return playlists

def personal_playlist_1():
    playlists = {"Hip Hop Playlist 1": "spotify:playlist:71sU6agJ13FCerhUW6tlll"}
    return playlists

def personal_playlist_2():
    playlists = {"EDM Playlist 1": "spotify:playlist:16bWFZT4i3MJzIsdoq2Su8"}
    return playlists